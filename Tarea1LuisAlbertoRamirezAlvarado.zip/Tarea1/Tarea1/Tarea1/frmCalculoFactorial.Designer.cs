#nullable disable
namespace Tarea1
{
    partial class frmCalculoFactorial
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitulo = new Label();
            grpSeccion1 = new GroupBox();
            lblIngrese = new Label();
            txtNumero = new TextBox();
            btnIterativo = new Button();
            btnRecursivo = new Button();
            lblUltimo = new Label();
            grpSeccion2 = new GroupBox();
            lblHistorial = new Label();
            txtHistorial = new TextBox();
            btnLimpiar = new Button();
            btnCerrar = new Button();
            grpSeccion1.SuspendLayout();
            grpSeccion2.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblTitulo.Location = new Point(0, 10);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(760, 40);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Cálculo de factoriales";
            lblTitulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // grpSeccion1
            // 
            grpSeccion1.Controls.Add(lblIngrese);
            grpSeccion1.Controls.Add(txtNumero);
            grpSeccion1.Controls.Add(btnIterativo);
            grpSeccion1.Controls.Add(btnRecursivo);
            grpSeccion1.Controls.Add(lblUltimo);
            grpSeccion1.Location = new Point(20, 60);
            grpSeccion1.Name = "grpSeccion1";
            grpSeccion1.Size = new Size(375, 250);
            grpSeccion1.TabIndex = 1;
            grpSeccion1.TabStop = false;
            grpSeccion1.Text = "Sección 1";
            // 
            // lblIngrese
            // 
            lblIngrese.AutoSize = true;
            lblIngrese.Location = new Point(10, 33);
            lblIngrese.Name = "lblIngrese";
            lblIngrese.Size = new Size(170, 15);
            lblIngrese.TabIndex = 0;
            lblIngrese.Text = "Ingrese un número entre 1 y 15";
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(215, 30);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(60, 23);
            txtNumero.TabIndex = 1;
            // 
            // btnIterativo
            // 
            btnIterativo.Location = new Point(10, 80);
            btnIterativo.Name = "btnIterativo";
            btnIterativo.Size = new Size(170, 40);
            btnIterativo.TabIndex = 2;
            btnIterativo.Text = "Calcular Factorial Iterativo";
            btnIterativo.Click += btnIterativo_Click;
            // 
            // btnRecursivo
            // 
            btnRecursivo.Location = new Point(190, 80);
            btnRecursivo.Name = "btnRecursivo";
            btnRecursivo.Size = new Size(170, 40);
            btnRecursivo.TabIndex = 3;
            btnRecursivo.Text = "Calcular Factorial Recursivo";
            btnRecursivo.Click += btnRecursivo_Click;
            // 
            // lblUltimo
            // 
            lblUltimo.Location = new Point(10, 140);
            lblUltimo.Name = "lblUltimo";
            lblUltimo.Size = new Size(355, 60);
            lblUltimo.TabIndex = 4;
            lblUltimo.Text = "Ultimo cálculo de factorial: ";
            // 
            // grpSeccion2
            // 
            grpSeccion2.Controls.Add(lblHistorial);
            grpSeccion2.Controls.Add(txtHistorial);
            grpSeccion2.Controls.Add(btnLimpiar);
            grpSeccion2.Location = new Point(405, 60);
            grpSeccion2.Name = "grpSeccion2";
            grpSeccion2.Size = new Size(335, 250);
            grpSeccion2.TabIndex = 2;
            grpSeccion2.TabStop = false;
            grpSeccion2.Text = "Sección 2";
            // 
            // lblHistorial
            // 
            lblHistorial.AutoSize = true;
            lblHistorial.Location = new Point(10, 25);
            lblHistorial.Name = "lblHistorial";
            lblHistorial.Size = new Size(190, 15);
            lblHistorial.TabIndex = 0;
            lblHistorial.Text = "Historial de Cálculos de Factoriales";
            // 
            // txtHistorial
            // 
            txtHistorial.Location = new Point(10, 50);
            txtHistorial.Multiline = true;
            txtHistorial.Name = "txtHistorial";
            txtHistorial.ReadOnly = true;
            txtHistorial.ScrollBars = ScrollBars.Both;
            txtHistorial.Size = new Size(315, 150);
            txtHistorial.TabIndex = 1;
            txtHistorial.WordWrap = false;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(10, 208);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(130, 30);
            btnLimpiar.TabIndex = 2;
            btnLimpiar.Text = "Limpiar historial";
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.Anchor = AnchorStyles.Bottom;
            btnCerrar.Location = new Point(330, 335);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(100, 35);
            btnCerrar.TabIndex = 3;
            btnCerrar.Text = "Cerrar";
            btnCerrar.Click += btnCerrar_Click;
            // 
            // frmCalculoFactorial
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.images;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(760, 390);
            Controls.Add(btnCerrar);
            Controls.Add(grpSeccion2);
            Controls.Add(grpSeccion1);
            Controls.Add(lblTitulo);
            Name = "frmCalculoFactorial";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cálculo de Factoriales";
            grpSeccion1.ResumeLayout(false);
            grpSeccion1.PerformLayout();
            grpSeccion2.ResumeLayout(false);
            grpSeccion2.PerformLayout();
            ResumeLayout(false);
        }

        private Label lblTitulo;
        private GroupBox grpSeccion1;
        private Label lblIngrese;
        private TextBox txtNumero;
        private Button btnIterativo;
        private Button btnRecursivo;
        private Label lblUltimo;
        private GroupBox grpSeccion2;
        private Label lblHistorial;
        private TextBox txtHistorial;
        private Button btnLimpiar;
        private Button btnCerrar;
    }
}
