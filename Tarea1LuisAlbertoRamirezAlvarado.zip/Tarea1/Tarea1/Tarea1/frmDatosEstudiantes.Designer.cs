#nullable disable
namespace Tarea1
{
    partial class frmDatosEstudiantes
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitulo = new Label();
            dgvEstudiantes = new DataGridView();
            colNombre = new DataGridViewTextBoxColumn();
            colCedula = new DataGridViewTextBoxColumn();
            colCarnet = new DataGridViewTextBoxColumn();
            colTelefono = new DataGridViewTextBoxColumn();
            colEmail = new DataGridViewTextBoxColumn();
            grpDatos = new GroupBox();
            lblNombre = new Label();
            txtNombre = new TextBox();
            lblCedula = new Label();
            txtCedula = new TextBox();
            lblCarnet = new Label();
            txtCarnet = new TextBox();
            lblTelefono = new Label();
            txtTelefono = new TextBox();
            lblEmail = new Label();
            txtEmail = new TextBox();
            btnAgregar = new Button();
            btnEditar = new Button();
            btnEliminar = new Button();
            btnCerrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvEstudiantes).BeginInit();
            grpDatos.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblTitulo.Location = new Point(0, 10);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(800, 40);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Lista de Estudiantes";
            lblTitulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // dgvEstudiantes
            // 
            dgvEstudiantes.AllowUserToAddRows = false;
            dgvEstudiantes.AllowUserToDeleteRows = false;
            dgvEstudiantes.AllowUserToResizeRows = false;
            dgvEstudiantes.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvEstudiantes.Columns.AddRange(new DataGridViewColumn[] { colNombre, colCedula, colCarnet, colTelefono, colEmail });
            dgvEstudiantes.Location = new Point(20, 60);
            dgvEstudiantes.MultiSelect = false;
            dgvEstudiantes.Name = "dgvEstudiantes";
            dgvEstudiantes.ReadOnly = true;
            dgvEstudiantes.RowHeadersVisible = false;
            dgvEstudiantes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEstudiantes.Size = new Size(760, 250);
            dgvEstudiantes.TabIndex = 1;
            dgvEstudiantes.CellClick += dgvEstudiantes_CellClick;
            // 
            // colNombre
            // 
            colNombre.Frozen = true;
            colNombre.HeaderText = "Nombre Completo";
            colNombre.Name = "colNombre";
            colNombre.ReadOnly = true;
            colNombre.SortMode = DataGridViewColumnSortMode.NotSortable;
            colNombre.Width = 200;
            // 
            // colCedula
            // 
            colCedula.HeaderText = "Cedula";
            colCedula.Name = "colCedula";
            colCedula.ReadOnly = true;
            colCedula.SortMode = DataGridViewColumnSortMode.NotSortable;
            colCedula.Width = 130;
            // 
            // colCarnet
            // 
            colCarnet.HeaderText = "Carnet";
            colCarnet.Name = "colCarnet";
            colCarnet.ReadOnly = true;
            colCarnet.SortMode = DataGridViewColumnSortMode.NotSortable;
            colCarnet.Width = 110;
            // 
            // colTelefono
            // 
            colTelefono.HeaderText = "Telefono";
            colTelefono.Name = "colTelefono";
            colTelefono.ReadOnly = true;
            colTelefono.SortMode = DataGridViewColumnSortMode.NotSortable;
            colTelefono.Width = 130;
            // 
            // colEmail
            // 
            colEmail.HeaderText = "Email";
            colEmail.Name = "colEmail";
            colEmail.ReadOnly = true;
            colEmail.SortMode = DataGridViewColumnSortMode.NotSortable;
            colEmail.Width = 170;
            // 
            // grpDatos
            // 
            grpDatos.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            grpDatos.Controls.Add(lblNombre);
            grpDatos.Controls.Add(txtNombre);
            grpDatos.Controls.Add(lblCedula);
            grpDatos.Controls.Add(txtCedula);
            grpDatos.Controls.Add(lblCarnet);
            grpDatos.Controls.Add(txtCarnet);
            grpDatos.Controls.Add(lblTelefono);
            grpDatos.Controls.Add(txtTelefono);
            grpDatos.Controls.Add(lblEmail);
            grpDatos.Controls.Add(txtEmail);
            grpDatos.Location = new Point(20, 320);
            grpDatos.Name = "grpDatos";
            grpDatos.Size = new Size(760, 110);
            grpDatos.TabIndex = 2;
            grpDatos.TabStop = false;
            grpDatos.Text = "Datos del estudiante";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(10, 33);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(51, 15);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "Nombre";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(90, 30);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(270, 23);
            txtNombre.TabIndex = 0;
            // 
            // lblCedula
            // 
            lblCedula.AutoSize = true;
            lblCedula.Location = new Point(380, 33);
            lblCedula.Name = "lblCedula";
            lblCedula.Size = new Size(44, 15);
            lblCedula.TabIndex = 1;
            lblCedula.Text = "Cedula";
            // 
            // txtCedula
            // 
            txtCedula.Location = new Point(450, 30);
            txtCedula.Name = "txtCedula";
            txtCedula.Size = new Size(150, 23);
            txtCedula.TabIndex = 1;
            // 
            // lblCarnet
            // 
            lblCarnet.AutoSize = true;
            lblCarnet.Location = new Point(10, 73);
            lblCarnet.Name = "lblCarnet";
            lblCarnet.Size = new Size(42, 15);
            lblCarnet.TabIndex = 2;
            lblCarnet.Text = "Carnet";
            // 
            // txtCarnet
            // 
            txtCarnet.Location = new Point(90, 70);
            txtCarnet.Name = "txtCarnet";
            txtCarnet.Size = new Size(130, 23);
            txtCarnet.TabIndex = 2;
            // 
            // lblTelefono
            // 
            lblTelefono.AutoSize = true;
            lblTelefono.Location = new Point(240, 73);
            lblTelefono.Name = "lblTelefono";
            lblTelefono.Size = new Size(53, 15);
            lblTelefono.TabIndex = 3;
            lblTelefono.Text = "Telefono";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(305, 70);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(120, 23);
            txtTelefono.TabIndex = 3;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(445, 73);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(36, 15);
            lblEmail.TabIndex = 4;
            lblEmail.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(495, 70);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(250, 23);
            txtEmail.TabIndex = 4;
            // 
            // btnAgregar
            // 
            btnAgregar.Anchor = AnchorStyles.Bottom;
            btnAgregar.Location = new Point(240, 445);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(100, 35);
            btnAgregar.TabIndex = 3;
            btnAgregar.Text = "Agregar";
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Anchor = AnchorStyles.Bottom;
            btnEditar.Location = new Point(350, 445);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(100, 35);
            btnEditar.TabIndex = 4;
            btnEditar.Text = "Editar";
            btnEditar.Click += btnEditar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Anchor = AnchorStyles.Bottom;
            btnEliminar.Location = new Point(460, 445);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(100, 35);
            btnEliminar.TabIndex = 5;
            btnEliminar.Text = "Eliminar";
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.Anchor = AnchorStyles.Bottom;
            btnCerrar.Location = new Point(350, 495);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(100, 35);
            btnCerrar.TabIndex = 6;
            btnCerrar.Text = "Cerrar";
            btnCerrar.Click += btnCerrar_Click;
            // 
            // frmDatosEstudiantes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.images;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 545);
            Controls.Add(btnCerrar);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnAgregar);
            Controls.Add(grpDatos);
            Controls.Add(dgvEstudiantes);
            Controls.Add(lblTitulo);
            Name = "frmDatosEstudiantes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Lista de Estudiantes";
            FormClosing += frmDatosEstudiantes_FormClosing;
            Load += frmDatosEstudiantes_Load;
            Shown += frmDatosEstudiantes_Shown;
            ((System.ComponentModel.ISupportInitialize)dgvEstudiantes).EndInit();
            grpDatos.ResumeLayout(false);
            grpDatos.PerformLayout();
            ResumeLayout(false);
        }

        private Label lblTitulo;
        private DataGridView dgvEstudiantes;
        private DataGridViewTextBoxColumn colNombre;
        private DataGridViewTextBoxColumn colCedula;
        private DataGridViewTextBoxColumn colCarnet;
        private DataGridViewTextBoxColumn colTelefono;
        private DataGridViewTextBoxColumn colEmail;
        private GroupBox grpDatos;
        private Label lblNombre;
        private TextBox txtNombre;
        private Label lblCedula;
        private TextBox txtCedula;
        private Label lblCarnet;
        private TextBox txtCarnet;
        private Label lblTelefono;
        private TextBox txtTelefono;
        private Label lblEmail;
        private TextBox txtEmail;
        private Button btnAgregar;
        private Button btnEditar;
        private Button btnEliminar;
        private Button btnCerrar;
    }
}
