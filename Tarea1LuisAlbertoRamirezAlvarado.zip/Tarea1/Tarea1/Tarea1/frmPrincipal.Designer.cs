#nullable disable
namespace Tarea1
{
    partial class frmPrincipal
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            mnuPrincipal = new MenuStrip();
            mniCalcularFactorial = new ToolStripMenuItem();
            mniAdministrarEstudiantes = new ToolStripMenuItem();
            mniSalir = new ToolStripMenuItem();
            stsPrincipal = new StatusStrip();
            lblFechaHora = new ToolStripStatusLabel();
            lblUsuario = new ToolStripStatusLabel();
            lblPc = new ToolStripStatusLabel();
            btnCalcularFactorial = new Button();
            btnDatosEstudiantes = new Button();
            btnSalir = new Button();
            tmrReloj = new System.Windows.Forms.Timer(components);
            mnuPrincipal.SuspendLayout();
            stsPrincipal.SuspendLayout();
            SuspendLayout();
            // 
            // mnuPrincipal
            // 
            mnuPrincipal.Items.AddRange(new ToolStripItem[] { mniCalcularFactorial, mniAdministrarEstudiantes, mniSalir });
            mnuPrincipal.Location = new Point(0, 0);
            mnuPrincipal.Name = "mnuPrincipal";
            mnuPrincipal.Size = new Size(800, 24);
            mnuPrincipal.TabIndex = 0;
            // 
            // mniCalcularFactorial
            // 
            mniCalcularFactorial.Name = "mniCalcularFactorial";
            mniCalcularFactorial.Size = new Size(110, 20);
            mniCalcularFactorial.Text = "Calcular Factorial";
            mniCalcularFactorial.Click += AbrirFactorial;
            // 
            // mniAdministrarEstudiantes
            // 
            mniAdministrarEstudiantes.Name = "mniAdministrarEstudiantes";
            mniAdministrarEstudiantes.Size = new Size(177, 20);
            mniAdministrarEstudiantes.Text = "Administrar Datos Estudiantes";
            mniAdministrarEstudiantes.Click += AbrirEstudiantes;
            // 
            // mniSalir
            // 
            mniSalir.Name = "mniSalir";
            mniSalir.Size = new Size(41, 20);
            mniSalir.Text = "Salir";
            mniSalir.Click += Salir;
            // 
            // stsPrincipal
            // 
            stsPrincipal.Items.AddRange(new ToolStripItem[] { lblFechaHora, lblUsuario, lblPc });
            stsPrincipal.Location = new Point(0, 428);
            stsPrincipal.Name = "stsPrincipal";
            stsPrincipal.Size = new Size(800, 22);
            stsPrincipal.TabIndex = 1;
            // 
            // lblFechaHora
            // 
            lblFechaHora.Name = "lblFechaHora";
            lblFechaHora.Size = new Size(38, 17);
            lblFechaHora.Text = "Fecha";
            // 
            // lblUsuario
            // 
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(53, 17);
            lblUsuario.Text = "Usuario: ";
            // 
            // lblPc
            // 
            lblPc.Name = "lblPc";
            lblPc.Size = new Size(28, 17);
            lblPc.Text = "PC: ";
            // 
            // btnCalcularFactorial
            // 
            btnCalcularFactorial.Anchor = AnchorStyles.None;
            btnCalcularFactorial.Location = new Point(300, 140);
            btnCalcularFactorial.Name = "btnCalcularFactorial";
            btnCalcularFactorial.Size = new Size(200, 45);
            btnCalcularFactorial.TabIndex = 2;
            btnCalcularFactorial.Text = "Calcular Factorial";
            btnCalcularFactorial.Click += AbrirFactorial;
            // 
            // btnDatosEstudiantes
            // 
            btnDatosEstudiantes.Anchor = AnchorStyles.None;
            btnDatosEstudiantes.Location = new Point(300, 200);
            btnDatosEstudiantes.Name = "btnDatosEstudiantes";
            btnDatosEstudiantes.Size = new Size(200, 45);
            btnDatosEstudiantes.TabIndex = 3;
            btnDatosEstudiantes.Text = "Datos Estudiantes";
            btnDatosEstudiantes.Click += AbrirEstudiantes;
            // 
            // btnSalir
            // 
            btnSalir.Anchor = AnchorStyles.None;
            btnSalir.Location = new Point(300, 260);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(200, 45);
            btnSalir.TabIndex = 4;
            btnSalir.Text = "Salir";
            btnSalir.Click += Salir;
            // 
            // tmrReloj
            // 
            tmrReloj.Enabled = true;
            tmrReloj.Interval = 1000;
            tmrReloj.Tick += tmrReloj_Tick;
            // 
            // frmPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.images;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSalir);
            Controls.Add(btnDatosEstudiantes);
            Controls.Add(btnCalcularFactorial);
            Controls.Add(stsPrincipal);
            Controls.Add(mnuPrincipal);
            MainMenuStrip = mnuPrincipal;
            Name = "frmPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Principal";
            Load += frmPrincipal_Load;
            mnuPrincipal.ResumeLayout(false);
            mnuPrincipal.PerformLayout();
            stsPrincipal.ResumeLayout(false);
            stsPrincipal.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private MenuStrip mnuPrincipal;
        private ToolStripMenuItem mniCalcularFactorial;
        private ToolStripMenuItem mniAdministrarEstudiantes;
        private ToolStripMenuItem mniSalir;
        private StatusStrip stsPrincipal;
        private ToolStripStatusLabel lblFechaHora;
        private ToolStripStatusLabel lblUsuario;
        private ToolStripStatusLabel lblPc;
        private Button btnCalcularFactorial;
        private Button btnDatosEstudiantes;
        private Button btnSalir;
        private System.Windows.Forms.Timer tmrReloj;
    }
}
