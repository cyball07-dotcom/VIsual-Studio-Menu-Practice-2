namespace Tarea1
{
    public partial class frmPrincipal : Form
    {
        private frmCalculoFactorial? formFactorial;
        private frmDatosEstudiantes? formEstudiantes;

        public frmPrincipal()
        {
            InitializeComponent();
            lblUsuario.Text = "Usuario: " + Environment.UserName;
            lblPc.Text = "PC: " + Environment.MachineName;
            ActualizarFechaHora();
        }

        private void ActualizarFechaHora()
        {
            lblFechaHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }

        private void MostrarFormulario<T>(ref T? formulario) where T : Form, new()
        {
            if (formulario == null || formulario.IsDisposed)
            {
                formulario = new T();
                formulario.Show(this);
            }
            else
            {
                formulario.Activate();
            }
        }

        private void tmrReloj_Tick(object? sender, EventArgs e)
        {
            ActualizarFechaHora();
        }

        private void AbrirFactorial(object? sender, EventArgs e)
        {
            MostrarFormulario(ref formFactorial);
        }

        private void AbrirEstudiantes(object? sender, EventArgs e)
        {
            MostrarFormulario(ref formEstudiantes);
        }

        private void Salir(object? sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
