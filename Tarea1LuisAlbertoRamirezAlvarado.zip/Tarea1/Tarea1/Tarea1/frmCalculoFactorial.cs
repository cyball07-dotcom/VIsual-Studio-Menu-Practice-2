namespace Tarea1
{
    public partial class frmCalculoFactorial : Form
    {
        private const int NumeroMinimo = 1;
        private const int NumeroMaximo = 15;

        public frmCalculoFactorial()
        {
            InitializeComponent();
        }

        private bool TryObtenerNumero(out int numero)
        {
            if (!int.TryParse(txtNumero.Text.Trim(), out numero) || numero < NumeroMinimo || numero > NumeroMaximo)
            {
                MessageBox.Show("Número inválido… Debe estar entre 1 y 15");
                return false;
            }
            return true;
        }

        private long FactorialIterativo(int n)
        {
            long resultado = 1;
            for (int i = 2; i <= n; i++)
            {
                resultado *= i;
            }
            return resultado;
        }

        private long FactorialRecursivo(int n)
        {
            if (n <= 1)
            {
                return 1;
            }
            return n * FactorialRecursivo(n - 1);
        }

        private void RegistrarResultado(string tipo, int numero, long resultado)
        {
            lblUltimo.Text = "Ultimo cálculo de factorial: " + tipo + " " + numero + "! = " + resultado;
            txtHistorial.AppendText(lblUltimo.Text + Environment.NewLine);
        }

        private void CalcularFactorial(string tipo, Func<int, long> calcular)
        {
            if (!TryObtenerNumero(out int numero))
            {
                return;
            }
            RegistrarResultado(tipo, numero, calcular(numero));
        }

        private void btnIterativo_Click(object? sender, EventArgs e)
        {
            CalcularFactorial("Iterativo", FactorialIterativo);
        }

        private void btnRecursivo_Click(object? sender, EventArgs e)
        {
            CalcularFactorial("Recursivo", FactorialRecursivo);
        }

        private void btnLimpiar_Click(object? sender, EventArgs e)
        {
            txtHistorial.Clear();
        }

        private void btnCerrar_Click(object? sender, EventArgs e)
        {
            Close();
        }
    }
}
