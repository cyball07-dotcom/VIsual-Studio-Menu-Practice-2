using System.Text.Json;

namespace Tarea1
{
    public partial class frmDatosEstudiantes : Form
    {
        private List<Estudiante> listaEstudiantes = new();
        private readonly string rutaArchivo = Path.Combine(AppContext.BaseDirectory, "datosEstudiantes.json");

        public frmDatosEstudiantes()
        {
            InitializeComponent();
        }

        private void frmDatosEstudiantes_Load(object? sender, EventArgs e)
        {
            listaEstudiantes = CargarDesdeArchivo();
            dgvEstudiantes.Rows.Clear();
            foreach (Estudiante estudiante in listaEstudiantes)
            {
                AgregarFila(estudiante);
            }
        }

        private void frmDatosEstudiantes_Shown(object? sender, EventArgs e)
        {
            dgvEstudiantes.ClearSelection();
        }

        private void frmDatosEstudiantes_FormClosing(object? sender, FormClosingEventArgs e)
        {
            GuardarEnArchivo();
        }

        private List<Estudiante> CargarDesdeArchivo()
        {
            if (!File.Exists(rutaArchivo))
            {
                return new List<Estudiante>();
            }
            try
            {
                string json = File.ReadAllText(rutaArchivo);
                return JsonSerializer.Deserialize<List<Estudiante>>(json) ?? new List<Estudiante>();
            }
            catch (JsonException)
            {
                MessageBox.Show("El archivo datosEstudiantes.json no tiene un formato válido");
                return new List<Estudiante>();
            }
        }

        private void GuardarEnArchivo()
        {
            string json = JsonSerializer.Serialize(listaEstudiantes, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(rutaArchivo, json);
        }

        private void AgregarFila(Estudiante estudiante)
        {
            dgvEstudiantes.Rows.Add(estudiante.nombreCompleto, estudiante.cedula, estudiante.carnet, estudiante.telefono, estudiante.email);
        }

        private void ActualizarFila(int indice, Estudiante estudiante)
        {
            DataGridViewRow fila = dgvEstudiantes.Rows[indice];
            fila.Cells[0].Value = estudiante.nombreCompleto;
            fila.Cells[1].Value = estudiante.cedula;
            fila.Cells[2].Value = estudiante.carnet;
            fila.Cells[3].Value = estudiante.telefono;
            fila.Cells[4].Value = estudiante.email;
        }

        private Estudiante LeerCampos()
        {
            return new Estudiante
            {
                nombreCompleto = txtNombre.Text.Trim(),
                cedula = txtCedula.Text.Trim(),
                carnet = txtCarnet.Text.Trim(),
                telefono = txtTelefono.Text.Trim(),
                email = txtEmail.Text.Trim()
            };
        }

        private void MostrarEnCampos(Estudiante estudiante)
        {
            txtNombre.Text = estudiante.nombreCompleto;
            txtCedula.Text = estudiante.cedula;
            txtCarnet.Text = estudiante.carnet;
            txtTelefono.Text = estudiante.telefono;
            txtEmail.Text = estudiante.email;
        }

        private void RestablecerFormulario()
        {
            txtNombre.Clear();
            txtCedula.Clear();
            txtCarnet.Clear();
            txtTelefono.Clear();
            txtEmail.Clear();
            dgvEstudiantes.ClearSelection();
        }

        private bool TryObtenerIndiceSeleccionado(out int indice)
        {
            indice = -1;
            if (dgvEstudiantes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Debe seleccionar un estudiante");
                return false;
            }
            indice = dgvEstudiantes.SelectedRows[0].Index;
            return true;
        }

        private bool ExisteRepetido(Func<Estudiante, string> campo, string valor, int indiceExcluido, string mensaje)
        {
            for (int i = 0; i < listaEstudiantes.Count; i++)
            {
                if (i != indiceExcluido && string.Equals(campo(listaEstudiantes[i]), valor, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show(mensaje);
                    return true;
                }
            }
            return false;
        }

        private bool ValidarCampos(int indiceExcluido)
        {
            Estudiante datos = LeerCampos();

            if (string.IsNullOrWhiteSpace(datos.nombreCompleto) || string.IsNullOrWhiteSpace(datos.cedula) ||
                string.IsNullOrWhiteSpace(datos.carnet) || string.IsNullOrWhiteSpace(datos.telefono) ||
                string.IsNullOrWhiteSpace(datos.email))
            {
                MessageBox.Show("Todos los campos son requeridos");
                return false;
            }

            if (ExisteRepetido(x => x.nombreCompleto, datos.nombreCompleto, indiceExcluido, "Ya existe un estudiante con ese nombre") ||
                ExisteRepetido(x => x.cedula, datos.cedula, indiceExcluido, "Ya existe un estudiante con esa cédula") ||
                ExisteRepetido(x => x.carnet, datos.carnet, indiceExcluido, "Ya existe un estudiante con ese carnet"))
            {
                return false;
            }
            return true;
        }

        private void dgvEstudiantes_CellClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < listaEstudiantes.Count)
            {
                MostrarEnCampos(listaEstudiantes[e.RowIndex]);
            }
        }

        private void btnAgregar_Click(object? sender, EventArgs e)
        {
            if (!ValidarCampos(-1))
            {
                return;
            }
            Estudiante nuevo = LeerCampos();
            listaEstudiantes.Add(nuevo);
            AgregarFila(nuevo);
            RestablecerFormulario();
        }

        private void btnEditar_Click(object? sender, EventArgs e)
        {
            if (!TryObtenerIndiceSeleccionado(out int indice) || !ValidarCampos(indice))
            {
                return;
            }
            Estudiante modificado = LeerCampos();
            listaEstudiantes[indice] = modificado;
            ActualizarFila(indice, modificado);
            RestablecerFormulario();
        }

        private void btnEliminar_Click(object? sender, EventArgs e)
        {
            if (!TryObtenerIndiceSeleccionado(out int indice))
            {
                return;
            }
            DialogResult respuesta = MessageBox.Show("Desea proceder con la eliminación", "Confirmación", MessageBoxButtons.YesNo);
            if (respuesta == DialogResult.Yes)
            {
                listaEstudiantes.RemoveAt(indice);
                dgvEstudiantes.Rows.RemoveAt(indice);
                RestablecerFormulario();
            }
        }

        private void btnCerrar_Click(object? sender, EventArgs e)
        {
            Close();
        }
    }

    public class Estudiante
    {
        public string nombreCompleto { get; set; } = string.Empty;
        public string cedula { get; set; } = string.Empty;
        public string carnet { get; set; } = string.Empty;
        public string telefono { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
    }
}
